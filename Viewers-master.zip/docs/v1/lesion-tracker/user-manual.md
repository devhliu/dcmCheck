# Lesion Tracker - User Manual

1. [Installation on Windows](../installation-on-windows.md)
2. [Manage Studies in Orthanc](../manage-studies-in-orthanc.md)
3. [User Accounts](../user-accounts.md)
4. [Study and Timepoint Management](../study-and-timepoint-management.md)
5. [Lesion Tracking](../lesion-tracking.md)
6. [User Preferences](../user-preferences.md)
7. [Server Management](../server-management.md)
8. [Audit Trail](../audit-trail.md)
