
This folder contains the OHIF Viewer installation instructions on the Microsoft Windows operating system
