# @ohif/extension-dicom-p10-downloader
