import en from './en';
import es from './es';
import de from './de';

export default {
  ...en,
  ...es,
  ...de,
};
