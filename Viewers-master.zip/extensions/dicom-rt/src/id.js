const id = 'rt';

export default id;
