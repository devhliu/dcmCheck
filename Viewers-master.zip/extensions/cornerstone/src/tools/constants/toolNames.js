const TOOL_NAMES = {
  DICOM_SR_DISPLAY_TOOL: 'DICOMSRDisplayTool',
};

export default TOOL_NAMES;
