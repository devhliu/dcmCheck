export default {
  COMMANDS: 'commandsModule',
  PANEL: 'panelModule',
  SOP_CLASS_HANDLER: 'sopClassHandlerModule',
  TOOLBAR: 'toolbarModule',
  VIEWPORT: 'viewportModule',
};
