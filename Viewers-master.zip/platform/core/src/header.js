//import Dropdown from './ui/dropdown/class.js';

/*
 * Defines the base OHIF header object
 */
//const dropdown = new OHIF.ui.Dropdown();
const header = {};

export default header;
