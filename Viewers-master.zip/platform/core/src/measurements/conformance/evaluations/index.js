import * as recistEvaluation from './recist.json';

export const recist11 = recistEvaluation;
