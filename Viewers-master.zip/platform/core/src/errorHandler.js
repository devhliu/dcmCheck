// These should be overridden by the implementation
const errorHandler = {
  getHTTPErrorHandler: () => null,
};

export default errorHandler;
